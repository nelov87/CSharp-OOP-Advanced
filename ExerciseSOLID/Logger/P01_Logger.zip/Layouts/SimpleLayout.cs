﻿namespace P01_Logger.Layouts
{
    using P01_Logger.Layouts.Contracts;

    public class SimpleLayout : ILayout
    {
        public string Format => "{0} - {1} - {2}";
    }
}
